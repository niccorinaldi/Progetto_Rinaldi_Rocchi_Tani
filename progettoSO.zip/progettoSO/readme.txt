!!!!!!!!!!!!   README   !!!!!!!!!!!!
Per avviare il programma è necessario eseguire i seguenti comandi su shell:

cc Avvia.c -o avvia
./avvia [MOD_AVVIO] [PATH_DATASET]

le modalità di avvio possono essere: "NORMALE" oppure "FALLIMENTO"

Una modalità di avvio diversa o un percorso al file non valido darà errore
