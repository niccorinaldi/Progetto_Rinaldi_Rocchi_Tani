Per il corretto avvio di questo progetto seguire i seguenti passi:
1- compilare il file "run.c" eseguendo il seguente comando da shell: "cc run.c -o run";
2- avviare l'eseguibile "run" creato al passo precedente passando come parametri la modalità di avvio e il file da analizzare: "./run MODALITA PATH".
