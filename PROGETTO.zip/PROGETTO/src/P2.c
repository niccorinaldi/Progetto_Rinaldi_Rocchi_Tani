#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h> /* For AFUNIX sockets */
#define DEFAULT_PROTOCOL 0
#define I_AM_ALIVE SIGUSR2

int LINESIZE;
int socketConnection();
int random_failure(int result);

void main(int argc, char* argv[])
{
    /* Ignoro i segnali SIGUSR1 e I_AM_ALIVE */
    signal(SIGUSR1, SIG_IGN);
    signal(I_AM_ALIVE, SIG_IGN);

    /* Definisco la lunghezza delle righe da leggere */
    LINESIZE = atoi(argv[1]);   

    /*definisco la modalità di avvio*/
    char MODE[15];
    strcpy(MODE, argv[0]);
    int failure;
    if(strcmp(MODE, "FALLIMENTO") == 0) {
        failure = 1;
    } else {
        failure = 0;
    }
    
    /* Creazione della socket P2socket */
    int serverFd, clientFd, serverLen, clientLen;
    struct sockaddr_un serverUNIXAddress;
    struct sockaddr *serverSockAddrPtr;  
    struct sockaddr_un clientUNIXAddress;
    struct sockaddr *clientSockAddrPtr;

    serverSockAddrPtr = (struct sockaddr *)&serverUNIXAddress;
    serverLen = sizeof(serverUNIXAddress);
    clientSockAddrPtr = (struct sockaddr *)&clientUNIXAddress;
    clientLen = sizeof(clientUNIXAddress);

    serverFd = socket(AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
    serverUNIXAddress.sun_family = AF_UNIX;
    strcpy(serverUNIXAddress.sun_path, "P2socket"); /* Setto il nome della socket */
    unlink("P2socket");                             /* Rimuovo il file se già esiste */
    bind(serverFd, serverSockAddrPtr, serverLen);
    listen(serverFd, 5);
    clientFd = accept(serverFd, clientSockAddrPtr, &clientLen);
    char line[LINESIZE];
    int result = 0;

    /* Connesione a decisionFunction */
    int DFclientFd = socketConnection();

    /* Creazione del buffer di invio */
    char sendBuff[6];

    while (1)
    {
        read(clientFd, line, LINESIZE);
        /*conteggio dei caratteri in ordine inverso*/
        for (int i = LINESIZE-1; i > -1; i--) 
        {
            if(line[i] != ',') {
                result += line[i];
            }
        }

        /* Modifica del risultato se avviato in modalità FALLIMENTO */
        if(failure == 1)
            result = random_failure(result);

        /* Invio del risultato a decisionFunction */
        snprintf(sendBuff,6,"%d\n",result);
        write(DFclientFd,sendBuff,6);
        result = 0;
    }
    close(clientFd);
    close(serverFd);
    close(DFclientFd);
}

int socketConnection() {
    int clientFd, serverLen, result;
    struct sockaddr_un serverUNIXAddress;
    struct sockaddr* serverSockAddrPtr;
    serverSockAddrPtr = (struct sockaddr*) &serverUNIXAddress;
    serverLen = sizeof (serverUNIXAddress);
    clientFd = socket (AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
    serverUNIXAddress.sun_family = AF_UNIX; /*dominio server*/
    strcpy (serverUNIXAddress.sun_path, "DFsocket");/*nome server*/

    do { /*itera finchè non viene stabilita la connessione*/
        result = connect (clientFd, serverSockAddrPtr, serverLen);
        if (result == -1) {
	        printf("connection problem P2;re-try in 1 sec\n");
	        sleep (1);
        }
    } while (result == -1);
    return clientFd;
}

int random_failure(int result) {
    srand(time(NULL)+20);  /* Imposto un valore casuale al seed della finzione random utilizzando time */

    /* Genero un numero casuale tra 0 e 9, se uguale a 7 modifico result */
    int rand = random()%10;
    if(rand == 7)    
        result += 20;
    return result;
}