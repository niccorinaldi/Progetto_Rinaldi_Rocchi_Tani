#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h> /* For AFUNIX sockets */
#define DEFAULT_PROTOCOL 0
#define I_AM_ALIVE SIGUSR2

int socketConnection();
int random_failure(int result);

void main(int argc, char *argv[])
{
    /* Ignoro i segnali SIGUSR1 e I_AM_ALIVE */
    signal(SIGUSR1, SIG_IGN);
    signal(I_AM_ALIVE, SIG_IGN);

    /* Definisco la lunghezza delle righe da leggere */
    int LINESIZE = atoi(argv[1]) - 1; 

    /*definisco la modalità di avvio*/  
    FILE *fp;
    char MODE[15];
    strcpy(MODE, argv[0]);
    int failure=0;
    if(strcmp(MODE, "FALLIMENTO") == 0) {
        failure = 1;
    } else {
        failure = 0;
    }
    /* Creazione di due buffer che ospiteranno i dati ricevuti
       da input manager, servono per poter capire quando 
       il file condiviso viene aggiornato */
    char line[LINESIZE], previusLine[LINESIZE];
    int result = 0;    
    
    do
    {
        fp = fopen("P3sharedFile.txt", "r");  /*Apertura del file condiviso*/
    } while (fp == NULL);
    fread(line, 1, LINESIZE, fp);
    printf("%s\n", line);

    /* Copio line in previusLine in modo da capire se il file è stato aggionato successivamente */
    strcpy(previusLine, line);
    
    /* Connessione a decisionFunction */
    int clientFd = socketConnection();

    /* Creazione del buffer di invio */
    char sendBuff[6];

    while (1)
    {
        /* Controllo che le stringhe siano diverse, altrimenti aspetto una modifica */
        if (strcmp(line, previusLine) != 0)
        {
            for (int i = 0; i < LINESIZE; i++) 
            {
                if(line[i] != ',') {
                    result += line[i];
                }
            }

            /* Modifica del risultato se avviato in modalità FALLIMENTO */
            if(failure == 1)
                result = random_failure(result);

            /* Invio del risultato a decisionFunction */
            snprintf(sendBuff,6,"%d\n",result);
            write(clientFd,sendBuff,6);
            result = 0;

            /* Aggiorno previusLine con il nuovo line */
            strcpy(previusLine, line);
        }
        fclose(fp);
        fp = fopen("P3sharedFile.txt", "r");
        fread(line, 1, LINESIZE, fp);
    }
    close(clientFd);
}

int socketConnection() {
    int clientFd, serverLen, result;
    struct sockaddr_un serverUNIXAddress;
    struct sockaddr* serverSockAddrPtr;
    serverSockAddrPtr = (struct sockaddr*) &serverUNIXAddress;
    serverLen = sizeof (serverUNIXAddress);
    clientFd = socket (AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
    serverUNIXAddress.sun_family = AF_UNIX; /*dominio server*/
    strcpy (serverUNIXAddress.sun_path, "DFsocket"); /*nome server*/

    do { /*itera finchè non viene stabilita la connessione*/
        result = connect (clientFd, serverSockAddrPtr, serverLen);
        if (result == -1) {
	        printf("connection problem P3;re-try in 1 sec\n");
	        sleep (1);
        }
    } while (result == -1);
    return clientFd;
}

int random_failure(int result) {
    /*Imposto un valore casuale al seed della finzione random utilizzando time */
    srand(time(NULL)+30);  
    
    /* Genero un numero casuale tra 0 e 9, se uguale a 1 modifico result */
    int rand = random()%10;
    if(rand == 7)    
        result += 30;
    return result;
}