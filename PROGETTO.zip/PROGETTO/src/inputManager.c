#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h> /* For AF_UNIX sockets */
#define DEFAULT_PROTOCOL 0
#define I_AM_ALIVE SIGUSR2
#define P1 "bin/P1"
#define P2 "bin/P2"
#define P3 "bin/P3"
#define DF "bin/DF"
#define FM "bin/FM"
#define WD "bin/WD"

int pipeConnection();
int socketConnection();
void childCreation(char MODE[15], char LINESIZE[4]);

int main(int argc, char* argv[]) {
    printf("\n*********************\n* AVVIO IN CORSO... *\n*********************\n");
    sleep(1);

    /* Ignoro i segnali SIGUSR1 e I_AM_ALIVE */
    signal(SIGUSR1, SIG_IGN);
    signal(I_AM_ALIVE, SIG_IGN);

    /* Apertura di dataset.csv */
    FILE *fpDataSet = fopen(argv[1], "r");
    if(fpDataSet==NULL) {
        perror("Errore apertura file.");
        exit(1);
    }

    /* Settaggio della modalità */
    char MODE[15];
    strcpy(MODE, argv[0]);
    if(strcmp(MODE,"NORMALE")==0 || strcmp(MODE,"FALLIMENTO")==0){
        printf("MODALITA': %s\n", MODE);
    }else{
        printf("Inserire una modalità valida: FALLIMENTO o NORMALE\n");
        kill(0,SIGKILL);
    }
    
    
    /* Impostazione del numero di caratteri da ignorare e del numero di caratteri di ogni riga */ 
    char buff[2500];
    fgets(buff,2500,fpDataSet);
    int IGNORED_LINE = (int) strlen(buff);
    fgets(buff,2500,fpDataSet);
    int LINESIZE = (int) strlen(buff);

    /* Salto della prima riga in lettura */
    fseek(fpDataSet, IGNORED_LINE, SEEK_SET);

    /* Creazione del buffer di invio */
    char line[LINESIZE];

    /*Apertura o creazione del file condiviso */
    FILE* sharedFile = fopen("P3sharedFile.txt", "w");

    /* Buffer per il passaggio di LINESIZE ai figli */
    char buffLinesize[4]; 
    snprintf(buffLinesize,4,"%d\n",LINESIZE);
    
    /* Creazione dei figli */
    childCreation(MODE, buffLinesize);

    /* Connessione alla pipe di P1*/
    int fdPipe = pipeConnection();

    /* Connessione alla socket di P2*/
    int clientFd = socketConnection();

    /* Messaggio all'utente di corretto funzionamento */
    printf("\nElaborazione dati in corso...\nPer interrompere il processo premere CTRL^C\n");


    /* Passaggio di una riga ai figli */
    while (1)
    {
        fgets(line, LINESIZE, fpDataSet);
        /* Inizio protocollo di invio */
        if(*line != '\n') {   /* Controllo per non passare una linea vuota */
            write(fdPipe, line, LINESIZE);
            write(clientFd, line, LINESIZE);
            
            /* Protocollo di invio a P3 */
            fputs(line, sharedFile);    
            fseek(sharedFile, 0, SEEK_SET);
            
            /*periodo di attesa di un secondo*/
            sleep(1);
        }
    }
    close(fdPipe);
    close(clientFd);
    fflush(sharedFile);
    fclose(sharedFile);
    return 0;
}

int socketConnection() {
    int clientFd, serverLen, result;
    struct sockaddr_un serverUNIXAddress;
    struct sockaddr* serverSockAddrPtr;
    serverSockAddrPtr = (struct sockaddr*) &serverUNIXAddress;
    serverLen = sizeof (serverUNIXAddress);
    clientFd = socket (AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
    serverUNIXAddress.sun_family = AF_UNIX; /*dominio del server*/
    strcpy (serverUNIXAddress.sun_path, "P2socket");/*nome del server*/

    do { /*itera finchè non viene stabilita la connessione*/
        result = connect (clientFd, serverSockAddrPtr, serverLen);
        if (result == -1) {
	        printf("connection problem;re-try in 1 sec\n");
	        sleep (1);
        }
    } while (result == -1);
    return clientFd;
}

int pipeConnection() {
    int fdPipe;
    do { /* Continua ad aprire il file finché non ha successo */
        fdPipe = open ("P1pipe", O_WRONLY); /* Apre la pipe con nome in sola scrittura*/
        if (fdPipe == -1) sleep (1);
    } while (fdPipe == -1);
    return fdPipe;
}

void childCreation(char MODE[15], char LINESIZE[4]) {
    int pid;

    pid = fork();    /*creazione di decisionFunction*/
    if(pid < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if(pid == 0) {
        execl(DF, NULL);
    }

    pid = fork();   /*Creazione P1*/
    if(pid < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if (pid == 0) {
        execl(P1, MODE, LINESIZE, NULL);
    }

    pid = fork();   /*Creazione di P2*/
    if(pid<0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if(pid == 0) {
        execl(P2, MODE, LINESIZE, NULL);
    }

    pid = fork();   /*Creazione di P3*/
    if(pid < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if(pid == 0) {
        execl(P3, MODE, LINESIZE, NULL);
    }

    pid = fork();   /*Creazione di failure manager*/
    if(pid < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if(pid == 0) {
        execl(FM, NULL);
    }

    pid = fork();   /*Creazione di watchdog*/
    if(pid < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(-1);
    } else if(pid == 0) {
        execl(WD, NULL);
    }
}