#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#define I_AM_ALIVE SIGUSR2

int killAll(int);

int main(int argc,char* argv){
    signal(SIGUSR1,killAll);
    signal(SIGINT, killAll);

    /* Ignoro il segnale I_AM_ALIVE */
    signal(I_AM_ALIVE, SIG_IGN);
    pause();
}

int killAll(int sig){
    printf("\nArresto in corso...\n");
    remove("P1pipe");
    remove("P2socket");
    remove("P3sharedFile.txt");
    remove("DFsocket");
    kill(0, SIGKILL);
}