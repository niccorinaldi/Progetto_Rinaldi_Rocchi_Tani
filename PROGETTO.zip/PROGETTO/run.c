#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/stat.h>
#include <stdio.h>

int main(int argc,char* argv[]){
    if(argc<3){
        printf("Fornire come input la modalità di avvio e percorso del file\n");
        kill(0,SIGKILL);
    }
    mkdir("bin",0777);
    mkdir("log",0777);
    if(fopen("log/alreadyInstalled.txt", "r+") == NULL) {
        fopen("log/alreadyInstalled.txt", "w+");
        printf("Inizio della compilazione...\n");
        sleep(1);
        system("cc src/inputManager.c -o bin/inputManager && cc src/P1.c -o bin/P1 && cc src/P2.c -o bin/P2 && cc src/P3.c -o bin/P3 && cc src/decisionFunction.c -o bin/DF && cc src/failureManager.c -o bin/FM && cc src/watchdog.c -o bin/WD > /dev/null");
        printf("\nCompilazione completata!\n");
    }
    execl("bin/inputManager",argv[1],argv[2], NULL);
}